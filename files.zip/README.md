# eCommerce Website

This is a simple eCommerce website built using Java and Spring Boot.

## Features

- User Registration and Login
- Product Listing
- Add to Cart
- Checkout

## Tech Stack

- Java
- Spring Boot
- Spring Data JPA
- Thymeleaf
- H2 Database (for development)

## Getting Started

### Prerequisites

- Java 11 or higher
- Maven or Gradle

### Installation

1. Clone the repository

```bash
git clone https://github.com/yourusername/ecommerce-website.git
cd ecommerce-website
```

2. Build and run the application

```bash
./mvnw spring-boot:run
```

3. Open your browser and go to `http://localhost:8080`

## Project Structure

- `src/main/java/com/example/ecommerce` - Main application package
  - `controller` - Web controllers
  - `model` - Entity classes
  - `repository` - Data repositories
  - `service` - Service classes
  - `config` - Configuration classes
- `src/main/resources/templates` - Thymeleaf templates
- `src/main/resources/static` - Static resources (CSS, JS, images)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.